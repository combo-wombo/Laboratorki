package com.example.lab10;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.security.Permission;
import java.util.List;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.opengl.GLSurfaceView;

public class MainActivity extends AppCompatActivity implements LocationListener {
    public double latitude;
    public double longitude;
    public LocationManager locationManager;
    public Criteria criteria;
    public String locationProvider;
    TextView textLat;
    TextView textLong;
    private GLSurfaceView glSurfaceView;
    private SensorManager sensorManager;
    private ExampleRenderer renderer;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            Intent i = new Intent(this, InfoActivity.class);
            startActivity(i);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.buttonGetLocation);
        textLat = findViewById(R.id.textLat);
        textLong = findViewById(R.id.textLong);
        glSurfaceView = findViewById(R.id.emptyView);

        button.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });

        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        renderer = new ExampleRenderer();
        glSurfaceView.setRenderer(renderer);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    protected void getLocation() {
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        criteria = new Criteria();
        locationProvider = String.valueOf(locationManager.getBestProvider(criteria, true));
        List<String> providers = locationManager.getProviders(true);

        int permissionCheck = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION);
        if(permissionCheck != PackageManager.PERMISSION_GRANTED) {
            // ask permissions here using below code
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                    1);
        } else {
            Location bestLocation = null;
            for (String provider : providers) {
                Location l = locationManager.getLastKnownLocation(provider);
                if (l == null) {
                    continue;
                }
                if (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy()) {
                    bestLocation = l;
                }
            }

            Location location = bestLocation;

            if (location != null) {
                latitude = location.getLatitude();
                longitude = location.getLongitude();
                textLat.setText(String.valueOf(latitude));
                textLong.setText(String.valueOf(longitude));
            }
            else{
                Toast.makeText(MainActivity.this, "No location ("+ locationProvider +") currently available", Toast.LENGTH_SHORT).show();
                locationManager.requestLocationUpdates(locationProvider, 1000, 0, this);
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    getLocation();
                }
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        Toast.makeText(MainActivity.this, "Location changed", Toast.LENGTH_SHORT).show();
        locationManager.removeUpdates(this);
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        textLat.setText(String.valueOf(latitude));
        textLong.setText(String.valueOf(longitude));
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderer.start();
        glSurfaceView.onResume();
    }
    class ExampleRenderer implements GLSurfaceView.Renderer, SensorEventListener {
        private final Cube cubeInstance;
        private final Sensor rotationSensor;
        private final float[] rotationMatrix = new float[16];
        public ExampleRenderer() {
            rotationSensor = sensorManager.getDefaultSensor(
                    Sensor.TYPE_ROTATION_VECTOR);
            cubeInstance = new Cube();
        }
        public void start() {
            sensorManager.registerListener(this, rotationSensor, 10000); //10 ms
        }
        public void onSensorChanged(SensorEvent event) {
            if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values);
            }
        }
        public void onDrawFrame(GL10 gl) {
            gl.glClear(GL10.GL_COLOR_BUFFER_BIT);
            gl.glMatrixMode(GL10.GL_MODELVIEW);
            gl.glLoadIdentity();
            gl.glTranslatef(0, 0, -4.0f);
            gl.glMultMatrixf(rotationMatrix, 0);
            gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
            gl.glEnableClientState(GL10.GL_COLOR_ARRAY);
            cubeInstance.draw(gl);
        }
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            gl.glViewport(0, 0, width, height);
            float ratio = (float) width / height;
            gl.glMatrixMode(GL10.GL_PROJECTION);
            gl.glLoadIdentity();
            gl.glFrustumf(-ratio, ratio, -1, 1, 1, 10);
        }
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            gl.glClearColor(1,1,1,1);
        }
        class Cube {
            public final FloatBuffer vertexBuf, colorBuf;
            public final ByteBuffer indexBuf;
            public Cube() {
                float[] vertices = {-1, -1, -1, 1, -1, -1, 1, 1, -1, -1, 1, -1, -1, -1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1};
                float[] colors = {
                        .1f, 0.9f, .5f, 1,
                        .8f, 0.95f, .2f, 1,
                        .6f, 0.8f, .1f, 1,
                        .23f, 1.f, .3f, 1,
                        .7f, 1.f, .4f, 1,
                        .8f, 0.8f, .2f, 1,
                        .2f, 0.6f, .2f, 1,
                        .6f, 1.f, .3f, 1};
                byte[] indices = {0, 4, 5, 0, 5, 1, 1, 5, 6, 1, 6, 2, 2, 6, 7, 2, 7, 3, 3, 7, 4, 3, 4, 0, 4, 7, 6, 4, 6, 5, 3, 0, 1, 3, 1, 2};

                ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length*4);
                vbb.order(ByteOrder.nativeOrder());
                vertexBuf = vbb.asFloatBuffer();
                vertexBuf.put(vertices);
                vertexBuf.position(0);

                indexBuf = ByteBuffer.allocateDirect(indices.length);
                indexBuf.put(indices);
                indexBuf.position(0);

                ByteBuffer cbb = ByteBuffer.allocateDirect(colors.length*4);
                cbb.order(ByteOrder.nativeOrder());
                colorBuf = cbb.asFloatBuffer();
                colorBuf.put(colors);
                colorBuf.position(0);
            }
            public void draw(GL10 gl) {
                gl.glEnable(GL10.GL_CULL_FACE);
                gl.glFrontFace(GL10.GL_CW);
                gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuf);
                gl.glColorPointer(4, GL10.GL_FLOAT, 0, colorBuf);
                gl.glDrawElements(GL10.GL_TRIANGLES, 36, GL10.GL_UNSIGNED_BYTE, indexBuf);
            }
        }
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    }
}