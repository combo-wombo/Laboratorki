package com.example.memorygame;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.preference.PreferenceManager;

import java.util.Timer;
import java.util.TimerTask;

public class GameField extends Activity {
    int SETTINGS_REQUEST = 1;
    private GridAdapter mAdapter;
    boolean counterReady = false;

    private Timer timer = new Timer();
    public TimerTask timerTask = new TimerTask() {
        @Override
        public void run() {
            if(counterReady){
                int time = mAdapter.gameTime;
                int tiles = mAdapter.tilesLeft;
                int tries = mAdapter.tries;
                TextView timeText = findViewById(R.id.timeText);
                if(mAdapter.paused){
                    timeText.setText("Time : " + time + " (paused)");
                } else {
                    timeText.setText("Time : " + time);
                }
                TextView tileText = findViewById(R.id.tileText);
                tileText.setText("Tiles Left : " + tiles);
                TextView triesText = findViewById(R.id.triesText);
                triesText.setText("Tries : " + tries);
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        int GRID_WIDTH = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getInt("gridWidth", 2) * 2;
        int GRID_HEIGHT = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getInt("gridHeight", 2) * 2;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_field);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels/2;

        GridView mGrid = findViewById(R.id.field);
        mGrid.setNumColumns(GRID_WIDTH);
        mGrid.setVerticalSpacing(height/GRID_HEIGHT);
        mGrid.setEnabled(true);
        mAdapter = new GridAdapter(getApplicationContext(), GRID_WIDTH, GRID_HEIGHT);
        mGrid.setAdapter(mAdapter);
        mGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                mAdapter.onPress(position);
                mAdapter.notifyDataSetChanged();
            }
        });
        Button buttonRestart = (Button) findViewById(R.id.buttonRestart);
        Button buttonPause = (Button) findViewById(R.id.buttonPause);
        Button buttonExit = (Button) findViewById(R.id.buttonExit);
        buttonRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAdapter.resetCells();
                mAdapter.notifyDataSetChanged();
                buttonPause.setText("pause");
                mGrid.setEnabled(true);
                mGrid.setBackgroundColor(Color.rgb(59, 59, 59));
            }
        });
        buttonPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean paused = mAdapter.pauseGame();
                if(paused){
                    Toast.makeText(getApplicationContext(), "paused", Toast.LENGTH_SHORT).show();
                    buttonPause.setText("unpause");
                    mGrid.setEnabled(false);
                    mGrid.setBackgroundColor(Color.rgb(163, 64, 64));
                } else {
                    Toast.makeText(getApplicationContext(), "unpaused", Toast.LENGTH_SHORT).show();
                    buttonPause.setText("pause");
                    mGrid.setEnabled(true);
                    mGrid.setBackgroundColor(Color.rgb(59, 59, 59));
                }
            }
        });
        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        counterReady = true;
        timer.schedule(timerTask, 0, 100);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if(requestCode == SETTINGS_REQUEST){
            this.finish();
            startActivity(this.getIntent());
        }
    }
}