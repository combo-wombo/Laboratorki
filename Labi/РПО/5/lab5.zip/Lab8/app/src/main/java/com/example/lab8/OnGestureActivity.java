package com.example.lab8;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class OnGestureActivity extends AppCompatActivity {

    String shape = "noShape";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gesture);

        Bundle extras = getIntent().getExtras();
        if(extras!=null){
            shape = extras.getString("shape");
        }

        if(!shape.equals("noShape")){
            ImageView gesturePicture = findViewById(R.id.gestureImage);
            TextView gestureName = findViewById(R.id.gestureText);

            switch(shape){
                case "star":
                    gestureName.setText("Star");
                    gesturePicture.setImageResource(android.R.drawable.btn_star_big_on);
                    break;
                case "circle":
                    gestureName.setText("Circle");
                    gesturePicture.setImageResource(android.R.drawable.presence_online);
                    break;
                case "square":
                    gestureName.setText("Square");
                    gesturePicture.setImageResource(android.R.drawable.picture_frame);
                    break;
                case "triangle":
                    gestureName.setText("Triangle");
                    gesturePicture.setImageResource(android.R.drawable.arrow_up_float);
                    break;
                case "infinity":
                    gestureName.setText("Infinity");
                    gesturePicture.setImageResource(android.R.drawable.ic_media_ff);
                    break;
            }
        }

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
