package com.example.lab8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.gesture.Gesture;
import android.gesture.GestureLibraries;
import android.gesture.GestureLibrary;
import android.gesture.GestureOverlayView;
import android.gesture.GestureOverlayView.OnGesturePerformedListener;
import android.gesture.Prediction;

import android.icu.text.IDNA;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnGesturePerformedListener {

    private GestureLibrary gestureLibrary;
    private TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        resultText = findViewById(R.id.results);

        gestureLibrary = (GestureLibrary) GestureLibraries.fromRawResource(MainActivity.this, R.raw.gestures);
        GestureOverlayView gestureOverlayView = (GestureOverlayView) findViewById(R.id.draw_gestures);
        if(!gestureLibrary.load()){
            finish();
        }
        gestureOverlayView.addOnGesturePerformedListener(MainActivity.this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_about, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            Intent i = new Intent(this, InfoActivity.class);
            startActivity(i);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onGesturePerformed(GestureOverlayView overlay, Gesture gesture){
        ArrayList<Prediction> predictions = gestureLibrary.recognize(gesture);
        NumberFormat format = new DecimalFormat("#0.00");
        StringBuilder predict = new StringBuilder("something went wrong");
        if(predictions.size() > 0){
            predict = new StringBuilder("This is a " + predictions.get(0).name + " (score " + format.format(predictions.get(0).score) + ")");
            predict.append("\n--------other predictions--------\n");
            for (int i = 1; i < predictions.size(); i++){
                predict.append(predictions.get(i).name).append(" (score ").append(format.format(predictions.get(i).score)).append(")\n");
            }
        }
        Toast.makeText(getApplicationContext(), predict, Toast.LENGTH_LONG).show();
        if(predictions.size() > 0){
            Intent i = new Intent(MainActivity.this, OnGestureActivity.class);
            i.putExtra("shape", predictions.get(0).name);
            startActivity(i);
        }
    }
}