package com.example.lab10;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import java.util.ArrayList;
public class PipeManager {
    private ArrayList<Pipe> pipes;
    private int playerGap;
    private int pipeGap;
    private long startTime;
    private long initTime;
    private int score=0;
    float speedMultiplier;
    private int pipeColor = Color.BLACK;
    private int backGroundColor = Color.WHITE;

    public PipeManager(int playerGap, int pipeGap) {
        this.playerGap = playerGap;
        this.pipeGap = pipeGap;
        startTime = System.currentTimeMillis();
        initTime = System.currentTimeMillis();
        pipes = new ArrayList<>();
        populatePipes();
    }

    public void draw(Canvas canvas, Paint paint) {
        canvas.drawColor(backGroundColor);
        for (Pipe pipe: pipes) {
            pipe.draw(canvas, paint);
        }
        paint.setColor(Color.BLUE);
        paint.setTextSize(50);
        canvas.drawText("Score: " + score, 60, 60 + paint.descent() - paint.ascent() , paint);
    }

    public void populatePipes() {
        int pipeCursorX = 5 * Globals.SCREEN_X / 4;
        for (int i = 0; i < 5; i++){
            int yStart = (int) (Math.random() * (Globals.SCREEN_Y - playerGap));
            pipes.add(new Pipe(pipeCursorX, yStart, playerGap, pipeColor));
            pipeCursorX += pipeGap + Globals.PIPE_X;
            i++;
        }
    }

    public void update() {
        boolean newPipeWasIntroduced = false;
        startTime = System.currentTimeMillis();
        float speed =  Globals.SCREEN_X / 260.f;
        speedMultiplier = (float) (Math.sqrt(1 + (startTime - initTime) / (10000.f)));
        speed *= speedMultiplier;

        for (Pipe pipe : pipes) {
            pipe.decrementX(speed);
        }

        if (pipes.get(0).getRectangle().right <= 0) {
            int yStart = (int) (Math.random() * (Globals.SCREEN_Y - playerGap));
            pipes.add(new Pipe(pipes.get(pipes.size() - 1).getRectangle().right + pipeGap, yStart, playerGap, pipeColor));
            pipes.remove(0);
            score++;
            newPipeWasIntroduced = true;
        }

        if(score != 0 && score %5 == 0 && newPipeWasIntroduced) {
            int red= (int) (Math.random() * 255);
            int green = (int) (Math.random() * 255);
            int blue = (int) (Math.random() * 255);
            pipeColor = Color.rgb(red, green, blue);
            for (Pipe pipe: pipes ) {
                pipe.setColor(pipeColor);
            }
            backGroundColor = Color.rgb(255 - red, 255 - green, 255 - blue);
        }
    }

    public boolean playerTouchedPipe(Player player) {
        for(Pipe pipe : pipes) {
            if(pipe.playerCollide(player)) {
                return true;
            }
        }
        return false;
    }

    public int getScore() {
        return score;
    }
}
