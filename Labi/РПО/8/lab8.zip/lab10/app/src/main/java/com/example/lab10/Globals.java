package com.example.lab10;
public class Globals {
    public static int SCREEN_X;
    public static int SCREEN_Y;
    public static int PIPE_X = 120;
}
