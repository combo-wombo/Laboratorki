package com.example.lab10;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
public class PlayerNameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_name);
        Intent intent = getIntent();

        Button button = findViewById(R.id.okButton);
        EditText nameField = findViewById(R.id.playerNameField);

        button.setOnClickListener(v -> {
            Intent nextIntent = new Intent(getBaseContext(), ScoreboardActivity.class);
            nextIntent.putExtra(ScoreboardActivity.EXTRA_NAME, nameField.getText().toString());
            nextIntent.putExtra(ScoreboardActivity.EXTRA_SCORE, intent.getIntExtra(ScoreboardActivity.EXTRA_SCORE, -1));
            startActivity(nextIntent);
        });
    }
}

