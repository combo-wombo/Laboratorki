package com.example.lab10;
import android.graphics.Canvas;
import android.graphics.Paint;
abstract class GameObject {
    abstract void draw(Canvas canvas, Paint paint);
}
