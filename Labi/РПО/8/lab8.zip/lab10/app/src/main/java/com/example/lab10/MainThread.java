package com.example.lab10;
import android.graphics.Canvas;
import android.view.SurfaceHolder;
public class MainThread extends Thread {
    public static final int MAX_FPS = 60;
    private final SurfaceHolder surfaceHolder;
    private GamePanel gamePanel;
    private boolean running;
    private static Canvas canvas;
    private Object lock = new Object();

    public MainThread(SurfaceHolder surfaceHolder, GamePanel gamePanel) {
        super();
        this.surfaceHolder = surfaceHolder;
        this.gamePanel = gamePanel;
    }

    public void setRunning(boolean running) {
        synchronized (lock) {
            this.running = true;
        }
    }

    public boolean isRunning() {
        synchronized (lock) {
            return this.running;
        }
    }

    @Override
    public void run() {
        long targetTime = 1000/MAX_FPS;

        while(isRunning()) {
            long startTime = System.nanoTime();
            canvas = null;

            try{
                canvas = this.surfaceHolder.lockCanvas();
                if (canvas != null) {
                    synchronized (surfaceHolder) {
                        this.gamePanel.update();
                        this.gamePanel.draw(canvas);
                    }
                } else {
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (canvas != null) {
                    try {
                        surfaceHolder.unlockCanvasAndPost(canvas);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            long timeMillis = (System.nanoTime() - startTime) / 1000000;
            long waitTime = targetTime - timeMillis;
            try {
                if(waitTime > 0) {
                    sleep(waitTime);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

