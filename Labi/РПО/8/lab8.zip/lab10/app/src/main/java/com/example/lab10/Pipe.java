package com.example.lab10;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
public class Pipe extends GameObject {
    private Rect pipeRect;
    private Rect pipeRect2;
    private int color;
    public Pipe(int startX, int startY, int playerGap, int color) {
        this.color = color;
        this.pipeRect = new Rect(startX, startY + playerGap, Globals.PIPE_X + startX, Globals.SCREEN_Y);
        this.pipeRect2 = new Rect(startX, 0, Globals.PIPE_X + startX, startY);
    }

    @Override
    public void draw(Canvas canvas, Paint paint) {
        paint.setColor(color);
        canvas.drawRect(pipeRect, paint);
        canvas.drawRect(pipeRect2, paint);
    }

    public void decrementX(Float x) {
        pipeRect.left -= x;
        pipeRect.right -= x;
        pipeRect2.left -= x;
        pipeRect2.right -= x;
    }

    public boolean playerCollide(Player player) {
        return Rect.intersects(pipeRect, player.getRectangle()) || Rect.intersects(pipeRect2, player.getRectangle());
    }

    public Rect getRectangle() {
        return pipeRect;
    }

    public void setColor(int color) {
        this.color = color;
    }
}

