package com.example.lab10;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.Objects;
public class ScoreboardActivity extends AppCompatActivity {
    public static final String TAG = "ScoreboardActivity";
    public static final String EXTRA_SCORE = "extra_score";
    public static final String EXTRA_NAME = "extra_name";
    public static final String EXTRA_ADDED = "extra_added";
    public ScoreDb dbHelper;
    private ListView scoreListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scoreboard);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        dbHelper = new ScoreDb(this);
        scoreListView = findViewById(R.id.scoreListView);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            dbHelper.deleteEntries();
            inflateList();
        });
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected void onResume() {
        addPlayerScore();
        inflateList();
        super.onResume();
    }

    private void addPlayerScore() {
        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_SCORE) && !intent.hasExtra(EXTRA_ADDED)) {
            Score score = new Score();
            score.name = intent.getStringExtra(EXTRA_NAME);
            score.score = intent.getIntExtra(EXTRA_SCORE, 0);
            try (SQLiteDatabase db = dbHelper.getWritableDatabase()) {
                score.saveToDb(db);
            } catch (Exception ex) {
                Log.e(TAG, "Exception while saving score: " + ex.getMessage());
            }
            intent.putExtra(EXTRA_ADDED, true);
        }
    }

    private void inflateList() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = ScoreDb.selectScores(db);
        ScoreAdapter adapter = new ScoreAdapter(this, c, 0);
        scoreListView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_scoreboard, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.aboutMenuItem) {
            Intent intent = new Intent(this, AboutActivity.class);
            startActivity(intent);
            return true;
        }
        return false;
    }
}

