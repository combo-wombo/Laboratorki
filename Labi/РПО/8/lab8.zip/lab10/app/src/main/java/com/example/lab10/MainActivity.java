package com.example.lab10;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        this.supportRequestWindowFeature(Window.FEATURE_NO_TITLE);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        Globals.SCREEN_X = dm.widthPixels;
        Globals.SCREEN_Y = dm.heightPixels;

        setContentView(new GamePanel(this));
    }
}

/*
 * ScoreDB           by Sem Rekkers on 18-1-2017.
 * ScoreAdapter      by Sem Rekkers on 18-1-2017.
 * Score             by Sem Rekkers on 18-1-2017.
 * Player            by janlindenberg on 17/01/2017.
 * PipeManager       by janlindenberg on 17/01/2017.
 * Pipe              by janlindenberg on 17/01/2017.
 * MainThread        by janlindenberg on 17/01/2017.
 * Everything else unknown.
 * All files were modified to my liking.
 */