package com.example.lab99;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class GalleryActivity extends AppCompatActivity {

    private final Integer[] pictures = {R.drawable.g1, R.drawable.g2, R.drawable.g3, R.drawable.g4, R.drawable.g5, R.drawable.g6, R.drawable.g7, R.drawable.g8};
    private int curIndex = 0;
    ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
        iv = (ImageView)findViewById(R.id.galleryImage);
        iv.setImageResource(pictures[curIndex]);

        Button prevButton = findViewById(R.id.buttonPrev);
        Button nextButton = findViewById(R.id.buttonNext);

        prevButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(curIndex == 0){
                            curIndex = pictures.length - 1;
                            iv.setImageResource(pictures[curIndex]);
                        }
                        else{
                            curIndex--;
                            iv.setImageResource(pictures[curIndex]);
                        }
                    }
                }
        );
        nextButton.setOnClickListener(
                new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(curIndex == pictures.length-1){
                    curIndex = 0;
                    iv.setImageResource(pictures[curIndex]);
                }
                else{
                    curIndex++;
                    iv.setImageResource(pictures[curIndex]);
                }
            }
        });
    }
}