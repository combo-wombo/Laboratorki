package com.example.android_lab_3;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;

public class LanguagesAll extends Fragment {
    private ArrayList<Language> capitalsData;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_capitals, container, false);

        capitalsData = new ArrayList<>();
        Collections.addAll(
                capitalsData,
                new Language("Python", R.drawable.python, "https://www.youtube.com/watch?v=x7X9w_GIm1s"),
                new Language("C++", R.drawable.cpp, "https://www.youtube.com/watch?v=MNeX4EGtR5Y"),
                new Language("C#", R.drawable.csharp, "https://www.youtube.com/watch?v=ravLFzIguCM"),
                new Language("Java", R.drawable.java, "https://www.youtube.com/watch?v=l9AzO1FMgM8"),
                new Language("Ruby", R.drawable.ruby, "https://www.youtube.com/watch?v=UYm0kfnRTJk"),
                new Language("Rust", R.drawable.rust, "https://www.youtube.com/watch?v=5C_HPTJg5ek")
        );

        ArrayList<String> capitalsTitles = new ArrayList<>();
        capitalsData.forEach(language -> capitalsTitles.add(language.getTitle()));


        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                view.getContext(),
                android.R.layout.simple_list_item_1,
                capitalsTitles
        );
        ListView capitalsListView = view.findViewById(R.id.capitals_list);
        capitalsListView.setAdapter(adapter);

        capitalsListView.setOnItemClickListener((adapterView, view1, i, l) -> {
            Intent intent = new Intent(view.getContext(), CapitalPage.class);
            intent.putExtra("title", capitalsData.get(i).getTitle());
            intent.putExtra("pictureId", capitalsData.get(i).getPictureId());
            intent.putExtra("videoUrl", capitalsData.get(i).getVideoUrl());
            startActivity(intent);
        });

        return view;
    }

    private class Language {
        private String title;
        private int pictureId;
        private String videoUrl;

        public Language(String title, int pictureId, String videoUrl) {
            this.title = title;
            this.pictureId = pictureId;
            this.videoUrl = videoUrl;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public void setPictureId(int pictureId) {
            this.pictureId = pictureId;
        }

        public void setVideoUrl(String videoUrl) {
            this.videoUrl = videoUrl;
        }

        public String getTitle() {
            return title;
        }

        public int getPictureId() {
            return pictureId;
        }

        public String getVideoUrl() {
            return videoUrl;
        }
    }
}