package com.example.android_lab_3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import java.util.Objects;

public class MainActivity extends AppCompatActivity {
//Lab5
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabLayout tabLayout = findViewById(R.id.tab_layout);
        ViewPager2 viewPager2 = findViewById(R.id.view_pager);

        ViewPageAdapter viewPageAdapter = new ViewPageAdapter(this);
        viewPager2.setAdapter(viewPageAdapter);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition());
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                Objects.requireNonNull(tabLayout.getTabAt(position)).select();
            }
        });
        /*
        FloatingActionButton changeBackgroundFab = findViewById(R.id.floating_btn);
        changeBackgroundFab.setOnClickListener(view -> {
            new AlertDialog.Builder(this)
                    .setTitle("Choose background color")
                    .setItems(backgroundColors, (dialogInterface, i) -> {
                        switch (i) {
                            case 0: {
                                viewPager2.setBackgroundColor(Color.RED);
                                showSnackBar();
                                break;
                            }
                            case 1: {
                                viewPager2.setBackgroundColor(Color.BLUE);
                                showSnackBar();
                                break;
                            }
                            case 2: {
                                viewPager2.setBackgroundColor(Color.GREEN);
                                showSnackBar();
                                break;
                            }
                            default: {
                                viewPager2.setBackgroundColor(Color.WHITE);
                                showSnackBar();
                            }
                        }
                    })
                    .setNegativeButton(android.R.string.cancel, null)
                    .setIcon(android.R.drawable.ic_menu_gallery)
                    .show();
        });
    */
    }

    private void showSnackBar() {
        Snackbar snackbar = Snackbar.make(
                findViewById(android.R.id.content),
                "Background was successfully changed",
                Snackbar.LENGTH_LONG
        );
        snackbar.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_about) {
            Intent i = new Intent(this, AboutActivity.class);
            startActivity(i);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}