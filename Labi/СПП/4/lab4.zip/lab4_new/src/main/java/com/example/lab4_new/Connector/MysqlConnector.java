package com.example.lab4_new.Connector;

import com.example.lab4_new.Controllers.HelloController;
import com.example.lab4_new.Model.Info;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MysqlConnector {
    public static HelloController mHelloController;
    public MysqlConnector(HelloController helloController) throws SQLException, ClassNotFoundException {
        mHelloController = helloController;
    }
    public List<Info> connection() throws ClassNotFoundException, SQLException {
        String url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection connection = DriverManager.getConnection(url, user, passwd)) {
            System.out.println("Connected to " + url + " as " + user + " (no passwd)");
            Statement statement = connection.createStatement();
            try {
                List<Info> list = new ArrayList<>();
                ResultSet result;
                System.out.println("Executing query...");
                result = statement.executeQuery(
                        "SELECT " +
                                "transport.id, " +
                                "transport.name, " +
                                "transport.number, " +
                                "routes.start, " +
                                "routes.end, " +
                                "periods.start, " +
                                "periods.end, " +
                                "tickets.cost, " +
                                "drivers.name " +
                                "FROM transport " +
                                "INNER JOIN routes ON transport.route_id = routes.id " +
                                "INNER JOIN periods ON transport.period_id = periods.id " +
                                "INNER JOIN tickets ON transport.ticket_id = tickets.id " +
                                "INNER JOIN drivers ON transport.driver_id = drivers.id ") ;

                System.out.println("Received stuff from db, reading...");
                while (result.next()) {
                    System.out.println("Creating info object from transport with id="+result.getInt("transport.id"));
                    list.add(
                            new Info(
                            result.getInt("transport.id"),
                            result.getString("routes.start"),
                            result.getString("routes.end"),
                            result.getString("periods.start"),
                            result.getString("periods.end"),
                            result.getString("tickets.cost"),
                            result.getString("transport.name"),
                            result.getString("transport.number"),
                            result.getString("drivers.name")
                            )
                    );
                }
                return list;
            } catch (Exception exception) {
                System.out.println(exception.getMessage());
            }
        }
        return null;
    }

    public List<Info> connectionFilter(String city) throws ClassNotFoundException, SQLException {
        String url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection connection = DriverManager.getConnection(url, user, passwd)) {
            System.out.println("Connected to " + url + " as " + user + " (no passwd)");
            Statement statement = connection.createStatement();
            try {
                List<Info> list = new ArrayList<>();
                ResultSet result;
                System.out.println("Executing query...");
                result = statement.executeQuery(
                        "SELECT " +
                                "transport.id, " +
                                "transport.name, " +
                                "transport.number, " +
                                "routes.start, " +
                                "routes.end, " +
                                "periods.start, " +
                                "periods.end, " +
                                "tickets.cost, " +
                                "drivers.name " +
                                "FROM transport " +
                                "INNER JOIN routes ON transport.route_id = routes.id " +
                                "INNER JOIN periods ON transport.period_id = periods.id " +
                                "INNER JOIN tickets ON transport.ticket_id = tickets.id " +
                                "INNER JOIN drivers ON transport.driver_id = drivers.id " +
                                "WHERE routes.start = '"+city+"'") ;

                System.out.println("Received stuff from db, reading...");
                while (result.next()) {
                    System.out.println("Creating info object from transport with id="+result.getInt("transport.id"));
                    list.add(
                            new Info(
                                    result.getInt("transport.id"),
                                    result.getString("routes.start"),
                                    result.getString("routes.end"),
                                    result.getString("periods.start"),
                                    result.getString("periods.end"),
                                    result.getString("tickets.cost"),
                                    result.getString("transport.name"),
                                    result.getString("transport.number"),
                                    result.getString("drivers.name")
                            )
                    );
                }
                return list;
            } catch (Exception exception) {
                System.out.println(exception.getMessage());
            }
        }
        return null;
    }

    public static List<String> getRoute() throws ClassNotFoundException {
        System.out.println("Getting available routes.");
        List<String> list = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        String sql = "SELECT * FROM routes";
        try (Connection connection = DriverManager.getConnection(url, user, passwd)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                list.add(resultSet.getString("start") + "-" + resultSet.getString("end"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println("Successfully got routes.");
        return list;
    }

    public static List<String> getTime() throws ClassNotFoundException {
        System.out.println("Getting available time.");
        List<String> list = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        String sql = "SELECT * FROM periods";
        try (Connection connection = DriverManager.getConnection(url, user, passwd)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                list.add(resultSet.getString("start") + "-" + resultSet.getString("end"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println("Time receive success.");
        return list;
    }

    public static List<String> getCost() throws ClassNotFoundException {
        System.out.println("Getting available cost.");
        List<String> list = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        String sql = "SELECT * FROM tickets";
        try (Connection connection = DriverManager.getConnection(url, user, passwd)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                list.add(resultSet.getString("cost"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println("Cost receive success.");
        return list;
    }

    public static List<String> getDriver() throws ClassNotFoundException {
        System.out.println("Getting available drivers.");
        List<String> list = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        String sql = "SELECT * FROM drivers";
        try (Connection connection = DriverManager.getConnection(url, user, passwd)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                list.add(resultSet.getString("name"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        System.out.println("Driver names receive success.");
        return list;
    }

    public static int getLastId() {
        return 0;
    }


    public static void insertInfo(Info info) throws ClassNotFoundException {
        System.out.println("insertInfo called.");
        String  url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd  = "";
        Class.forName("com.mysql.cj.jdbc.Driver");

        String sql = "insert into transport (name, number, route_id, period_id, ticket_id, driver_id) " +
                "values ((?), (?),"+
                "(SELECT id FROM routes where start = ? AND end = ?)," +
                "(SELECT id FROM periods where start = ? AND end = ?)," +
                "(SELECT id FROM tickets where cost = ?)," +
                "(SELECT id FROM drivers where name = ?))";

        try(Connection connection = DriverManager.getConnection(url, user, passwd)) {
            System.out.println("Connected, inserting info...");
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, info.getTransportName());
            preparedStatement.setString(2, info.getTransportNumber());
            preparedStatement.setString(3, info.getPathStart());
            preparedStatement.setString(4, info.getPathEnd());
            preparedStatement.setString(5, info.getTimeStart());
            preparedStatement.setString(6, info.getTimeEnd());
            preparedStatement.setString(7, info.getCost());
            preparedStatement.setString(8, info.getDriverName());
            preparedStatement.executeUpdate();
            System.out.println("Success. Refreshing...");
            mHelloController.onClickRefresh();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static void updateInfo(Info info) throws ClassNotFoundException {
        System.out.println("updateInfo called.");
        String  url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd  = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        String sql = "UPDATE transport SET name = ?, number = ?, " +
                "route_id = (SELECT id FROM routes where start = ? AND end = ?)," +
                "period_id = (SELECT id FROM periods where start = ? AND end = ?)," +
                "ticket_id = (SELECT id FROM tickets where cost = ?)," +
                "driver_id = (SELECT id FROM drivers where name = ?) " +
                "WHERE id = ?";

        try(Connection connection = DriverManager.getConnection(url, user, passwd)) {
            System.out.println("Connected, updating info...");
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, info.getTransportName());
            preparedStatement.setString(2, info.getTransportNumber());
            preparedStatement.setString(3, info.getPathStart());
            preparedStatement.setString(4, info.getPathEnd());
            preparedStatement.setString(5, info.getTimeStart());
            preparedStatement.setString(6, info.getTimeEnd());
            preparedStatement.setString(7, info.getCost());
            preparedStatement.setString(8, info.getDriverName());
            preparedStatement.setInt(9, info.getId());
            preparedStatement.executeUpdate();
            System.out.println("Success. Refreshing...");
            mHelloController.onClickRefresh();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }


    public static void deleteInfo(int ID) throws ClassNotFoundException {
        System.out.println("deleteInfo called.");
        String url = "jdbc:mysql://localhost:3306/spp", user = "root", passwd = "";
        Class.forName("com.mysql.cj.jdbc.Driver");
        String sql = "DELETE FROM transport WHERE id = ?";
        try (Connection connection = DriverManager.getConnection(url, user, passwd)) {
            System.out.println("Connected, deleting...");
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, ID);
            preparedStatement.executeUpdate();
            System.out.println("Success. Refreshing...");
            mHelloController.onClickRefresh();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
