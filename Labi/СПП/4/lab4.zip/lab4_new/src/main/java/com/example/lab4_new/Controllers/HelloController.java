package com.example.lab4_new.Controllers;

import com.example.lab4_new.Connector.MysqlConnector;
import com.example.lab4_new.Model.Info;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HelloController {

    public HelloController() throws SQLException, ClassNotFoundException {
        System.out.println("Creating new DBConnector object.");
        bdController = new MysqlConnector(this);
    }
    public TableView<Info> table;
    @FXML
    private TableColumn<Info, String> idColumn;
    @FXML
    private TableColumn<Info, String> transportNameColumn;
    @FXML
    private TableColumn<Info, String> transportNumberColumn;
    @FXML
    private TableColumn<Info, String> pathStartColumn;
    @FXML
    private TableColumn<Info, String> pathEndColumn;
    @FXML
    private TableColumn<Info, String> timeStartColumn;
    @FXML
    private TableColumn<Info, String> timeEndColumn;
    @FXML
    private TableColumn<Info, String> costColumn;
    @FXML
    private TableColumn<Info, String> driverNameColumn;

    public ObservableList<Info> listview = FXCollections.observableArrayList();

    public int id;
    public String transportName;
    public String transportNumber;
    public String pathStart;
    public String pathEnd;
    public String timeStart;
    public String timeEnd;
    public String cost;
    public String driverName;

    private final MysqlConnector bdController;
    @FXML
    public Button Add;
    @FXML
    public Button Change;
    @FXML
    public Button Delete;
    @FXML
    public Button Refresh;
    @FXML
    public Button AllInfo;

    @FXML
    void initialize() throws SQLException, ClassNotFoundException {
        try {
            System.out.println("Initializing HelloController...");
            listview.addAll(bdController.connection());
            for(Info i: listview ){
                System.out.println("- - - - - - - - - - - - - -");
                System.out.println(" ID : " + i.getId());
                System.out.println("NAME: " + i.getTransportName());
                System.out.println("NUMB: " + i.getTransportNumber());
                System.out.println("PSTR: " + i.getPathStart());
                System.out.println("PEND: " + i.getPathEnd());
                System.out.println("TSRT: " + i.getTimeStart());
                System.out.println("TEND: " + i.getTimeEnd());
                System.out.println("COST: " + i.getCost());
                System.out.println("DNME: " + i.getDriverName());
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }
        idColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("id"));
        transportNameColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("transportName"));
        transportNumberColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("transportNumber"));
        pathStartColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("pathStart"));
        pathEndColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("pathEnd"));
        timeStartColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("timeStart"));
        timeEndColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("timeEnd"));
        costColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("cost"));
        driverNameColumn.setCellValueFactory(new PropertyValueFactory<Info, String>("driverName"));

        table.setItems(listview);
        table.getSortOrder().add(idColumn);

        TableView.TableViewSelectionModel<Info> selectionModel = table.getSelectionModel();
        selectionModel.selectedItemProperty().addListener(new ChangeListener<Info>(){

            @Override
            public void changed(ObservableValue<? extends Info> observableValue, Info oldval, Info newVal) {
                if(newVal != null) {
                    System.out.println("New row selected. ID="+newVal.getId());
                    id = newVal.getId();
                    transportName = newVal.getTransportName();
                    transportNumber = newVal.getTransportNumber();
                    pathStart = newVal.getPathStart();
                    pathEnd = newVal.getPathEnd();
                    timeStart = newVal.getTimeStart();
                    timeEnd = newVal.getTimeEnd();
                    cost = newVal.getCost();
                    driverName = newVal.getDriverName();
                }
            }
        });
    }

    public void onClickRefresh() throws SQLException, ClassNotFoundException {
        System.out.println("Refresh called, clearing and re-adding elements.");
        listview.clear();
        listview.addAll(bdController.connection());
        table.setItems(listview);
        table.getSortOrder().add(idColumn);
    }

    public void onClickAdd(ActionEvent actionEvent) {
        System.out.println("Add clicked, creating scene.");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            fxmlLoader.setLocation(getClass().getResource("/com/example/lab4_new/insert.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 400, 400);
            Stage stage = new Stage();
            stage.setTitle("Add Element");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            Logger logger = Logger.getLogger(getClass().getName());
            logger.log(Level.SEVERE, "Failed to create new Window.", e.getMessage());
        }
    }

    public void onClickChange(ActionEvent actionEvent) {
        System.out.println("Change clicked, creating scene and setting up info.");
        try {
            FXMLLoader fxmlLoader = new FXMLLoader();
            EditController.setInfo(id, transportName, transportNumber, pathStart + "-" + pathEnd, timeStart + "-" + timeEnd, cost, driverName);
            fxmlLoader.setLocation(getClass().getResource("/com/example/lab4_new/update.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 400, 400);
            Stage stage = new Stage();
            stage.setTitle("Update Element");
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            System.out.println(e.getMessage());
            Logger logger = Logger.getLogger(getClass().getName());
            logger.log(Level.SEVERE, "Failed to create new Window.", e.getMessage());
        }
    }

    public void onClickDelete(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        System.out.println("Delete clicked, calling deleteInfo(id).");
        if(id < 1) return;
        MysqlConnector.deleteInfo(id);
        id = 0;
    }

    public void onClickFilter(ActionEvent actionEvent) throws SQLException, ClassNotFoundException {
        System.out.println("Filter clicked.");
        TextInputDialog td = new TextInputDialog();
        td.setHeaderText("Enter city to show:");
        td.showAndWait();
        String city = td.getEditor().getText();
        listview.clear();
        listview.addAll(bdController.connectionFilter(city));
        table.setItems(listview);
        table.getSortOrder().add(idColumn);
    }
}