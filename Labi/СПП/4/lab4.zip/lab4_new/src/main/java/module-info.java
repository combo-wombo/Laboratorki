module com.example.lab4_new {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.java;

    opens com.example.lab4_new to javafx.fxml;
    exports com.example.lab4_new;
    exports com.example.lab4_new.Controllers;
    opens com.example.lab4_new.Controllers to javafx.fxml;
    exports com.example.lab4_new.Connector;
    opens com.example.lab4_new.Connector to javafx.fxml;
    exports com.example.lab4_new.Model;
    opens com.example.lab4_new.Model to javafx.fxml;
}