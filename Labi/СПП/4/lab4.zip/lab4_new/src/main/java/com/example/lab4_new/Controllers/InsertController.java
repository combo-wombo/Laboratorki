package com.example.lab4_new.Controllers;

import com.example.lab4_new.Connector.MysqlConnector;
import com.example.lab4_new.Model.Info;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class InsertController {

    @FXML
    public Button bottonOk;
    @FXML
    public TextField Name;
    @FXML
    public TextField Number;
    @FXML
    public ComboBox<String> Route;
    @FXML
    public ComboBox<String> Time;
    @FXML
    public ComboBox<String> Cost;
    @FXML
    public ComboBox<String> DriverName;
    Info insertableInfo;

    @FXML
    void initialize() {
        try {
            ObservableList<String> RouteList = FXCollections.observableArrayList(MysqlConnector.getRoute());
            Route.setItems(RouteList);

            ObservableList<String> TimeList = FXCollections.observableArrayList(MysqlConnector.getTime());
            Time.setItems(TimeList);

            ObservableList<String> CostList = FXCollections.observableArrayList(MysqlConnector.getCost());
            Cost.setItems(CostList);

            ObservableList<String> DriverList = FXCollections.observableArrayList(MysqlConnector.getDriver());
            DriverName.setItems(DriverList);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void onClickInsert(ActionEvent actionEvent) throws ClassNotFoundException {
        if(Name.getText() == null || Number.getText() == null || Route.getValue() == null || Time.getValue() == null || Cost.getValue() == null || DriverName.getValue() == null) return;
        String[] pathTokens = Route.getValue().split("-");
        String[] timeTokens = Time.getValue().split("-");
        System.out.println(pathTokens[0]);
        System.out.println(pathTokens[1]);
        System.out.println(timeTokens[0]);
        System.out.println(timeTokens[1]);
        if(pathTokens.length == 2 && timeTokens.length == 2){
            insertableInfo = new Info(
                MysqlConnector.getLastId() + 1,
                pathTokens[0],
                pathTokens[1],
                timeTokens[0],
                timeTokens[1],
                Cost.getValue(),
                Name.getText(),
                Number.getText(),
                DriverName.getValue());
            MysqlConnector.insertInfo(insertableInfo);
        }
        Stage stage = (Stage) bottonOk.getScene().getWindow();
        stage.close();
    }
}