package com.example.lab4_new.Controllers;

import com.example.lab4_new.Connector.MysqlConnector;
import com.example.lab4_new.Model.Info;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EditController {

    @FXML
    public Button bottonOk;
    @FXML
    public TextField Name;
    @FXML
    public TextField Number;
    @FXML
    public ComboBox<String> Route;
    @FXML
    public ComboBox<String> Time;
    @FXML
    public ComboBox<String> Cost;
    @FXML
    public ComboBox<String> DriverName;


    public static int id;
    public static String name;
    public static String number;
    public static String route;
    public static String time;
    public static String cost;
    public static String driverName;

    Info insertableInfo;

    public static void setInfo(int ID, String Name, String Number, String Route, String Time, String Cost, String DriverName) {
        id = ID;
        name = Name;
        number = Number;
        route = Route;
        time = Time;
        cost = Cost;
        driverName = DriverName;
    }

    @FXML
    void initialize() {
        try {
            Name.setText(name);
            Number.setText(number);

            ObservableList<String> RouteList = FXCollections.observableArrayList(MysqlConnector.getRoute());
            Route.setItems(RouteList);
            Route.setValue(route);

            ObservableList<String> TimeList = FXCollections.observableArrayList(MysqlConnector.getTime());
            Time.setItems(TimeList);
            Time.setValue(time);

            ObservableList<String> CostList = FXCollections.observableArrayList(MysqlConnector.getCost());
            Cost.setItems(CostList);
            Cost.setValue(cost);

            ObservableList<String> DriverList = FXCollections.observableArrayList(MysqlConnector.getDriver());
            DriverName.setItems(DriverList);
            DriverName.setValue(driverName);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void onClickUpdate(ActionEvent actionEvent) throws ClassNotFoundException {
        if(Name.getText() == null || Number.getText() == null || Route.getValue() == null || Time.getValue() == null || Cost.getValue() == null || DriverName.getValue() == null) return;
        String[] pathTokens = Route.getValue().split("-");
        String[] timeTokens = Time.getValue().split("-");
        System.out.println(pathTokens[0]);
        System.out.println(pathTokens[1]);
        System.out.println(timeTokens[0]);
        System.out.println(timeTokens[1]);
        if(pathTokens.length == 2 && timeTokens.length == 2){
            insertableInfo = new Info(
                    id,
                    pathTokens[0],
                    pathTokens[1],
                    timeTokens[0],
                    timeTokens[1],
                    Cost.getValue(),
                    Name.getText(),
                    Number.getText(),
                    DriverName.getValue());
            MysqlConnector.updateInfo(insertableInfo);
        }
        Stage stage = (Stage) bottonOk.getScene().getWindow();
        stage.close();
    }
}