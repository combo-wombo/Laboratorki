package com.example.lab4_new.Model;

public class Info {
    int     id;
    String  transportName;
    String  transportNumber;
    String  pathStart;
    String  pathEnd;
    String  timeStart;
    String  timeEnd;
    String  cost;
    String  driverName;

    public Info(int id, String pathStart, String pathEnd, String timeStart, String timeEnd, String cost, String transportName, String transportNumber, String driver) {
        this.id = id;
        this.pathStart = pathStart;
        this.pathEnd = pathEnd;
        this.timeStart = timeStart;
        this.timeEnd = timeEnd;
        this.cost = cost;
        this.transportName = transportName;
        this.transportNumber = transportNumber;
        this.driverName = driver;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPathStart() {
        return pathStart;
    }

    public void setPathStart(String pathStart) {
        this.pathStart = pathStart;
    }

    public String getPathEnd() {
        return pathEnd;
    }

    public void setPathEnd(String pathEnd) {
        this.pathEnd = pathEnd;
    }

    public String getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(String timeStart) {
        this.timeStart = timeStart;
    }

    public String getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getTransportName() {
        return transportName;
    }

    public void setTransportName(String transportName) {
        this.transportName = transportName;
    }

    public String getTransportNumber() {
        return transportNumber;
    }

    public void setTransportNumber(String transportNumber) {
        this.transportNumber = transportNumber;
    }
}
