import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ServerGUI extends JFrame implements ActionListener, WindowListener {
    private static final long serialVersionUID = 1L;
    private JButton stopStartButton;
    private JTextArea chatTextArea, eventTextArea;
    private JTextField portTextEdit;
    private Server server;

    ServerGUI(int port) {
        super("Chat server");
        server = null;
        portTextEdit = new JTextField(" " + port);
        stopStartButton = new JButton("Start");
        stopStartButton.addActionListener(this);
        chatTextArea = new JTextArea(90, 90);
        chatTextArea.setEditable(false);
        eventTextArea = new JTextArea(90, 90);
        eventTextArea.setEditable(false);
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Port: "));
        topPanel.add(portTextEdit);
        topPanel.add(stopStartButton);
        add(topPanel, BorderLayout.NORTH);
        JPanel centerPanel = new JPanel(new GridLayout(2, 1));
        centerPanel.add(new JScrollPane(chatTextArea));
        centerPanel.add(new JScrollPane(eventTextArea));
        add(centerPanel);
        addWindowListener(this);
        appendRoom("This is the chat window.\nThe chat messages will be displayed here.");
        appendEvent("This is the events log window.\nHere will the system messages appear.");
        setSize(400, 500);
        setVisible(true);
    }

    void appendRoom(String str) {
        chatTextArea.append(str);
        chatTextArea.setCaretPosition(chatTextArea.getText().length() - 1);
    }

    void appendEvent(String str) {
        eventTextArea.append(str);
        eventTextArea.setCaretPosition(chatTextArea.getText().length() - 1);
    }

    public void actionPerformed(ActionEvent event) {
        if (server != null) {
            server.stop();
            server = null;
            portTextEdit.setEditable(true);
            stopStartButton.setText("Starting");
            return;
        }
        int port;
        try { port = Integer.parseInt(portTextEdit.getText().trim()); }
        catch (Exception exception) {
            appendEvent("Invalid port number");
            return;
        }
        server = new Server(port, this);
        new ServerRunning().start();
        stopStartButton.setText("Stop");
        portTextEdit.setEditable(false);
    }

    public static void main(String[] arg) {
        new ServerGUI(1200);
    }

    public void windowClosing(WindowEvent event) {
        if (server != null) {
            try { server.stop(); }
            catch (Exception ignored) {}
            server = null;
        }
        dispose();
        System.exit(0);
    }

    public void windowClosed(WindowEvent event) {}
    public void windowOpened(WindowEvent event) {}
    public void windowIconified(WindowEvent event) {}
    public void windowDeiconified(WindowEvent event) {}
    public void windowActivated(WindowEvent event) {}
    public void windowDeactivated(WindowEvent event) {}

    class ServerRunning extends Thread {
        public void run() {
            server.start();
            stopStartButton.setText("Start");
            portTextEdit.setEditable(true);
            appendEvent("Server is stopped\n");
            server = null;
        }
    }
}