import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;

/*
 * This server can be run as a console application or as a GUI
 * To run as a console application just:
 * > java Server
 * > java Server portNumber
 * If the port number is not specified 1200-port is used
 */

public class Server {
    private static int uniqueId;                // ID counter
    private ArrayList<ClientThread> clients;    // Client threads list
    private ServerGUI serverGUI;              
    private SimpleDateFormat simpleDateFormat;
    private int port;
    private boolean isRunning;

    public Server(int port) {
        this(port, null);
    }

    public Server(int port, ServerGUI serverGUI) {
        this.serverGUI = serverGUI;
        this.port = port;
        simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
        clients = new ArrayList<>();
    }

    public void start() {
        isRunning = true;
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            while (isRunning) {
                display("Waiting for clients on port" + port);
                Socket socket = serverSocket.accept();
                if (!isRunning) break;
                ClientThread thread = new ClientThread(socket);
                clients.add(thread);
                thread.start();
            }
            try {
                serverSocket.close();
                for (ClientThread clientThread : clients) {
                    try {
                        clientThread.sInput.close();
                        clientThread.sOutput.close();
                        clientThread.socket.close();
                    } catch (IOException ignored) {}
                }
            }
            catch (Exception exception) {
                display("Can't close connections. \n" + exception);
            }
        }
        catch (IOException ioException) {
            String message = simpleDateFormat.format(new Date()) + " IOException. \n" + ioException;
            display(message);
        }
    }

    protected void stop() {
        isRunning = false;
        try {
            new Socket("localhost", port);
        }
        catch (Exception ignored) {}
    }

    private void display(String message) {                  // Displaying the event
        String time = simpleDateFormat.format(new Date()) + " " + message;
        if (serverGUI == null) System.out.println(time);
        else serverGUI.appendEvent(time + "\n");
    }

    private synchronized void broadcast(String message) {
        String time = simpleDateFormat.format(new Date());
        String messageAndTime = time + " " + message + "\n";
        if (serverGUI == null) System.out.print(messageAndTime);
        else serverGUI.appendRoom(messageAndTime); 
        for (int i = clients.size(); --i >= 0; ) {  
            ClientThread clientThread = clients.get(i);
            if (!clientThread.writeMessage(messageAndTime)) {
                clients.remove(i);
                display("Disconnected client " + clientThread.username);
            }
        }
    }

    synchronized void remove(int id) {
        for (int i = 0; i < clients.size(); ++i) {
            ClientThread clientThread = clients.get(i);
            if (clientThread.id == id) {
                clients.remove(i);
                return;
            }
        }
    }

    public static void main(String[] args) {
        int portNumber = 1200;
        switch (args.length) {
            case 1:
                try { portNumber = Integer.parseInt(args[0]); }
                catch (Exception exception) {
                    System.out.println("Invalid port number.");
                    System.out.println("Usage is: > java Server [portNumber]");
                    return;
                }
            case 0:
                break;
            default:
                System.out.println("Usage is: > java Server [portNumber]");
                return;
        }
        Server server = new Server(portNumber);
        server.start();
    }

    class ClientThread extends Thread {
        Socket socket;
        ObjectInputStream sInput;
        ObjectOutputStream sOutput;
        int id;
        String username;
        Message clientMessage;
        String currentDate;

        ClientThread(Socket socket) {
            id = ++uniqueId;
            this.socket = socket;
            try {
                sOutput = new ObjectOutputStream(socket.getOutputStream());
                sInput = new ObjectInputStream(socket.getInputStream());
                username = (String) sInput.readObject();
                display(username + " has connected.");
            }
            catch (IOException exception) {
                display("IOStream create error. \n" + exception);
                return;
            }
            catch (ClassNotFoundException ignored) {}
            currentDate = new Date().toString();
        }

        public void run() {
            boolean keepGoing = true;
            while (keepGoing) {
                try {
                    clientMessage = (Message) sInput.readObject();
                }
                catch (IOException exception) {
                    display(username + " stream exception. \n" + exception);
                    break;
                }
                catch (ClassNotFoundException exception) {
                    break;
                }
                String message = clientMessage.getMessage();            // The message part
                switch (clientMessage.getType()) {                      // Switcher of the types
                    case Message.MESSAGE -> broadcast(username + ": " + message);
                    case Message.LOGOUT -> {
                        display(username + " disconnected from room.");
                        keepGoing = false;
                    }
                    case Message.WHOISIN -> {
                        writeMessage("List of the guests connected at " + simpleDateFormat.format(new Date()) + "\n");
                        for (int i = 0; i < clients.size(); ++i) {
                            ClientThread clientThread = clients.get(i);
                            writeMessage((i + 1) + ") " + clientThread.username + " since " + clientThread.currentDate + "\n");
                        }
                    }
                }
            }
            remove(id);
            close();
        }

        private void close() {
            try {
                if (sOutput != null) sOutput.close();
            }
            catch (Exception ignored) {}
            try {
                if (sInput != null) sInput.close();
            }
            catch (Exception ignored) {}
            try {
                if (socket != null) socket.close();
            }
            catch (Exception ignored) {}
        }

        private boolean writeMessage(String message) {
            if (!socket.isConnected()) {
                close();
                return false;
            }
            try {
                sOutput.writeObject(message);
            }
            catch (IOException exception) {
                display("Message send error. " + username);
                display(exception.toString());
            }
            return true;
        }
    }
}