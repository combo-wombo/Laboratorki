import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ClientGUI extends JFrame implements ActionListener {
    private static final long serialVersionUID = 1L;
    private JLabel statusLabel;
    private JTextField loginTextEdit;
    private JTextField addressTextEdit, portTextEdit;
    private JButton loginButton, logoutButton, peopleButton;
    private JTextArea chatTextArea;
    private boolean connected;
    private Client client;
    private int usedPort;
    private String usedHost;

    ClientGUI(String host, int port) {
        super("Chat window");
        usedPort = port;
        usedHost = host;
        addressTextEdit = new JTextField(host);
        portTextEdit = new JTextField("" + port);
        portTextEdit.setHorizontalAlignment(SwingConstants.RIGHT);
        statusLabel = new JLabel("Enter your username ", SwingConstants.CENTER);
        loginTextEdit = new JTextField("Guest");
        loginTextEdit.setBackground(Color.WHITE);
        JPanel serverAndPort = new JPanel(new GridLayout(1,5, 1, 3));
        serverAndPort.add(new JLabel("Address: "));
        serverAndPort.add(addressTextEdit);
        serverAndPort.add(new JLabel("Port: "));
        serverAndPort.add(portTextEdit);
        serverAndPort.add(new JLabel(""));
        JPanel nordPanel = new JPanel(new GridLayout(3,1));
        nordPanel.add(statusLabel);
        nordPanel.add(serverAndPort);
        nordPanel.add(loginTextEdit);
        add(nordPanel, BorderLayout.NORTH);

        chatTextArea = new JTextArea("Client started. You can now connect to a room.\n", 70, 70);
        JPanel centralPanel = new JPanel(new GridLayout(1,1));
        centralPanel.add(new JScrollPane(chatTextArea));
        chatTextArea.setEditable(false);
        add(centralPanel, BorderLayout.CENTER);

        loginButton = new JButton("Connect");
        loginButton.addActionListener(this);
        logoutButton = new JButton("Disconnect");
        logoutButton.addActionListener(this);
        logoutButton.setEnabled(false);
        peopleButton = new JButton("Who's here?");
        peopleButton.addActionListener(this);
        peopleButton.setEnabled(false);
        JPanel downPanel = new JPanel();
        downPanel.add(loginButton);
        downPanel.add(logoutButton);
        downPanel.add(peopleButton);
        add(downPanel, BorderLayout.SOUTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(500, 400);
        setVisible(true);
        loginTextEdit.requestFocus();
    }

    void connectionFailed() {
        loginButton.setEnabled(true);
        logoutButton.setEnabled(false);
        peopleButton.setEnabled(false);
        statusLabel.setText("Enter your username");
        loginTextEdit.setText("Guest");
        portTextEdit.setText("" + usedPort);
        addressTextEdit.setText(usedHost);
        addressTextEdit.setEditable(false);
        portTextEdit.setEditable(false);
        loginTextEdit.removeActionListener(this);
        chatTextArea.append("connection error, try again.");
        chatTextArea.setCaretPosition(chatTextArea.getText().length() - 1);
        connected = false;
    }

    public void actionPerformed(ActionEvent event) {
        Object tempObject = event.getSource();
        if (tempObject == logoutButton) {
            connectionFailed();
            client.sendMessage(new Message(Message.LOGOUT, ""));
            return;
        }
        if (tempObject == peopleButton) {
            client.sendMessage(new Message(Message.WHOISIN, ""));
            return;
        }
        if (connected) {                 // Come from the JTextField
            client.sendMessage(new Message(Message.MESSAGE, loginTextEdit.getText()));
            loginTextEdit.setText("");
            return;
        }
        if (tempObject == loginButton) {
            String username = loginTextEdit.getText().trim();
            if (username.length() == 0)
                return;
            String server = addressTextEdit.getText().trim();
            if (server.length() == 0)
                return;
            String portNumber = portTextEdit.getText().trim();
            if (portNumber.length() == 0)
                return;
            int port;
            try {
                port = Integer.parseInt(portNumber);
            }
            catch(Exception exception) {
                return;
            }
            client = new Client(server, port, username, chatTextArea, this);
            if (!client.start()) return;
            loginTextEdit.setText("");
            statusLabel.setText("Enter your message below");
            connected = true;
            loginButton.setEnabled(false);
            logoutButton.setEnabled(true);
            peopleButton.setEnabled(true);
            addressTextEdit.setEditable(false);
            portTextEdit.setEditable(false);
            loginTextEdit.addActionListener(this);
        }
    }

    public static void main(String[] args) {
        new ClientGUI("localhost", 1200);
    }

    private void initComponents() {
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 300, Short.MAX_VALUE)
        );
        pack();
    }
}