import javax.swing.*;
import java.net.*;
import java.io.*;
import java.util.*;

/*
 * To start the Client-part in console mode use one of the following command
 * > java Client
 * > java Client username
 * > java Client username portNumber
 * > java Client username portNumber serverAddress
 * at the console prompt
 * If the portNumber is not specified 1200 is used
 * If the serverAddress is not specified "localHost" is used
 * If the username is not specified "Guest" is used
 * > java Client
 * > java Client Anonymous 1200 localhost
 */

public class Client {
    private ObjectInputStream sInput;
    private ObjectOutputStream sOutput;
    private Socket socket;
    private boolean isGUI;
    private ClientGUI clientGUI;
    private JTextArea textGUI;
    private String server, username;
    private int port;

    Client(String server, int port, String username) {
        this(server, port, username, null, null);
        this.isGUI = false;
    }

    Client(String server, int port, String username, JTextArea textArea, ClientGUI clientGUI) {
        this.server = server;
        this.port = port;
        this.username = username;
        this.textGUI = textArea;
        this.isGUI = true;
    }

    public boolean start() {
        try { socket = new Socket(server, port); }
        catch (Exception exception) {
            display("Connection error. \n" + exception);
            return false;
        }
        String message = "Connection accepted " + socket.getInetAddress() + ":" + socket.getPort();
        display(message);
        try {
            sInput = new ObjectInputStream(socket.getInputStream());
            sOutput = new ObjectOutputStream(socket.getOutputStream());
        }
        catch (IOException IOException) {
            display("IOStream error. \n" + IOException);
            return false;
        }
        new ListenFromServer().start();
        try {
            sOutput.writeObject(username);
        }
        catch (IOException IOException) {
            display("Login error. \n" + IOException);
            disconnect();
            return false;
        }
        return true;
    }

    private void display(String message) {
        if (isGUI) {
            textGUI.append(message + "\n");
            textGUI.setCaretPosition(textGUI.getText().length() - 1);
        } else {
            System.out.println(message);
        }

    }

    void sendMessage(Message message) {             // Send to the server
        try {
            sOutput.writeObject(message);
        }
        catch (IOException exception) {
            display("Send message error. \n" + exception);
        }
    }

    private void disconnect() {
        try {
            if (sInput != null) sInput.close();
        }
        catch (Exception ignored) {}
        try {
            if (sOutput != null) sOutput.close();
        }
        catch (Exception ignored) {}
        try {
            if (socket != null) socket.close();
        }
        catch (Exception ignored) {}
        if (clientGUI != null)
            clientGUI.connectionFailed();
    }

    public static void main(String[] args) {
        int portNumber = 1200;
        String serverAddress = "localhost";
        String userName = "Guest";
        switch (args.length) {
            case 3:
                serverAddress = args[2];
            case 2:
                try {
                    portNumber = Integer.parseInt(args[1]);
                }
                catch (Exception exception) {
                    System.out.println("Invalid port number.");
                    System.out.println("Usage is: > java Client [username] [portNumber] [serverAddress]");
                    return;
                }
            case 1:
                userName = args[0];
            case 0:
                break;
            default:
                System.out.println("Usage is: > java Client [username] [portNumber] {serverAddress]");
                return;
        }
        Client client = new Client(serverAddress, portNumber, userName);
        if (!client.start()) return;
        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.print("> ");
            String message = scan.nextLine();
            if (message.equalsIgnoreCase("LOGOUT")) {
                client.sendMessage(new Message(Message.LOGOUT, ""));
                break;
            }
            else if (message.equalsIgnoreCase("WHOISIN")) {
                client.sendMessage(new Message(Message.WHOISIN, ""));
            }
            else {
                System.out.println("New message.");
                client.sendMessage(new Message(Message.MESSAGE, message));
            }
        }
        client.disconnect();
    }

    class ListenFromServer extends Thread {
        public void run() {
            while (true) {
                try {
                    String message = (String) sInput.readObject();
                    if (isGUI) {
                        textGUI.append(message);
                        textGUI.setCaretPosition(textGUI.getText().length() - 1);
                    } else {
                        System.out.println(">" + message);
                    }
                }
                catch (IOException exception) {
                    display("Server has close the connection: " + exception);
                    if (clientGUI != null)
                        clientGUI.connectionFailed();
                    break;
                }
                catch (ClassNotFoundException ignored) {}
            }
        }
    }
}