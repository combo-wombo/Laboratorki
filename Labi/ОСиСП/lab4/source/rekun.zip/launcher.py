from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui, uic, QtTest
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from threading import *
from GameRPS import Game
from github import Github
import random
import sys
import os

class Thread(QThread):
    _signal = pyqtSignal(int)
    def __init__(self,contents,repo):
        super(Thread, self).__init__()
        self.contents = contents
        self.repo = repo

    def run(self):
        len1 = len(self.contents) +1
        while self.contents:
            percentage = round((len(self.contents)/len1)*100)
            print("percentage", percentage)
            file_content = self.contents.pop(0)
            self._signal.emit(100-percentage)
            if file_content.type == "dir":
                self.contents.extend(self.repo.get_contents(file_content.path))
            else:
                if(len(file_content.path) > len(file_content.name)):
                    print("Checking " + file_content.path)
                    if not os.path.isdir(file_content.path[:(len(file_content.path) - len(file_content.name))]):
                        print("\"" + file_content.path + "\" does not exist, creating...")
                        os.makedirs(file_content.path[:(len(file_content.path) - len(file_content.name))])
                print("Writing " + file_content.name)
                binary_file = open(file_content.path, "wb")
                if file_content.encoding != 'base64':
                    binary_file.write(b'encoding unsupported')
                    binary_file.close()
                else:
                    binary_file.write(file_content.decoded_content)
                    binary_file.close()
        self._signal.emit(999)

class Launcher(QDialog):
    def __init__(self):
        super(Launcher, self).__init__()
        uic.loadUi("ui/launcher.ui", self)
        self.statusT = self.findChild(QLabel, "statusText")
        self.playB = self.findChild(QPushButton, "playB")
        self.updateB = self.findChild(QPushButton, "updateB")
        self.progBar = self.findChild(QProgressBar, "progress")

        self.statusT.setText("Version: " + self.getLocalVersion())
        self.playB.clicked.connect(self.playClicked)
        self.updateB.clicked.connect(self.updateClicked)
        self.show()

    def showLauncher(self):
        self.show()

    def playClicked(self):
        self.hide()
        self.game = Game(self.getLocalVersion())
        self.game.closed.connect(self.showLauncher)

    def updateClicked(self):
        self.Update()

    ################################################################################################

    def getLocalVersion(self): #read version from version.txt
        try:
            version_file = open("version.txt")
            version = version_file.readline()
            return version
        except OSError:
            print("could not open file")
            return None

    def getRemoteVersion(self): #get repo version
        repo = self.githubInstance.get_repo(self.repository)
        return repo.get_contents("version.txt").decoded_content.decode()


    def Authenticate(self,token): #auth
        self.statusT.setText("Getting update info...")
        g = Github(token)
        return g

    def noUpdateNeeded(self): #no update needed
        print("No update needed.")
        self.statusT.setText("No update needed.")
        self.updateNotFound = QMessageBox(
            QMessageBox.Information, "No update needed",
            "You are already running the latest version, no need to update.",
            (QMessageBox.Ok)
            )
        self.updateNotFound.exec()
        self.statusT.setText("Version: " + self.getLocalVersion())

    def showUpdateConfirm(self,lcVersion, rmVersion): #up detected, show a msgbox to confirm
        self.updateConfirm = QMessageBox(
            QMessageBox.Information, "Update detected",
            "A new update has been detected. Your local version is " + lcVersion + ". Are you willing to update your game version to " + rmVersion + "?",
            (QMessageBox.Yes | QMessageBox.No)
            )
        return self.updateConfirm.exec()

    def Update(self):
        self.access_token = "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"
        self.repository = "combo-wombo/OSiSP_Lab4"
        self.githubInstance = self.Authenticate(self.access_token)
        self.repo = self.githubInstance.get_repo(self.repository)
        self.contents = self.repo.get_contents("")
        local = self.getLocalVersion()
        remote = self.getRemoteVersion()
        if(local < remote):
            self.statusT.setText("Update detected!")
            if(self.showUpdateConfirm(local, remote) == QMessageBox.Yes):
                self.thread = Thread(self.contents,self.repo)
                self.thread._signal.connect(self.signal_accept)
                self.thread.start()
            else:
                self.statusT.setText("Version: " + self.getLocalVersion())
                self.progBar.setValue(0)
        else:
            self.noUpdateNeeded()

    def signal_accept(self, msg):
        msg = int(msg)
        print("received",msg)
        if msg == 999:
                self.progBar.setValue(100)
                QtTest.QTest.qWait(800)
                self.statusT.setText("Version: " + self.getLocalVersion())
                self.progBar.setValue(0)
                self.updatedInfo = QMessageBox(
                QMessageBox.Information, "Updated",
                "Updated to the latest version.",
                (QMessageBox.Ok)
                )
                _ = self.updatedInfo.exec()
                QtCore.QCoreApplication.quit()
                status = QtCore.QProcess.startDetached(sys.executable, sys.argv)
                print(status)
        else:
            if self.progBar.value() > 99:
                self.progBar.setValue(100)
                self.statusT.setText("Updating: 100%")
            else:
                self.statusT.setText("Updating: " + str(msg) + "%")
                self.progBar.setValue(msg)

app = QApplication(sys.argv)
window = Launcher()
app.exec_()