from PyQt5.QtWidgets import *
from PyQt5 import QtCore, QtGui
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import random
import sys

class Game(QMainWindow):
	closed = pyqtSignal()
	def __init__(self, version):
		super().__init__()
		if(float(version) > 0.4):
			self.updated = True
		else:
			self.updated = False
		self.started = 0
		self.setWindowTitle("Game")
		self.setGeometry(100, 100, 320, 400)
		self.UiComponents()
		self.show()

	def UiComponents(self):
		self.counter = -1
		self.choice = 0
		self.language_selected("en")
		if (self.updated):
			lang_select = QComboBox()
			i_en = QIcon('images/en.jpg')
			i_ru = QIcon('images/ru.png')
			lang_select.addItem(i_en, 'en')
			lang_select.addItem(i_ru, 'ru')
			lang_select.setGeometry(18,334,60,23)
			layout = self.layout()
			lang_select.currentTextChanged.connect(self.language_selected)
			layout.addWidget(lang_select)
			self.setStyleSheet("QMainWindow{background-color: qlineargradient(spread:pad, x1:0, y1:1, x2:0, y2:0, stop:0 #06c7b4, stop:1 #ff9966);}")
			self.mainFont = 'Arial'
			self.styleStr = "border : 2px dotted black; background : white;"
		else:
			self.mainFont = 'Times'
			self.styleStr = "border : 2px solid black; background : white;"

		self.head = QLabel(self.headText, self)
		self.head.setGeometry(20, 10, 280, 60)
		font = QFont(self.mainFont, 15)
		font.setBold(True)
		font.setItalic(True)
		font.setUnderline(True)
		self.head.setFont(font)
		self.head.setAlignment(Qt.AlignCenter)
		self.vs = QLabel(self.vsText, self)
		self.vs.setGeometry(150, 110, 30, 50)
		font.setUnderline(False)
		font.setItalic(False)
		self.vs.setFont(font)
		self.user = QLabel(self.youText, self)
		self.user.setGeometry(50, 100, 70, 70)
		self.user.setStyleSheet(self.styleStr)
		self.user.setAlignment(Qt.AlignCenter)
		self.computer = QLabel(self.computerText, self)
		self.computer.setGeometry(200, 100, 70, 70)
		self.computer.setStyleSheet(self.styleStr)
		self.computer.setAlignment(Qt.AlignCenter)
		self.result = QLabel(self)
		self.result.setGeometry(25, 200, 270, 50)
		self.result.setFont(QFont(self.mainFont, 14))
		self.result.setAlignment(Qt.AlignCenter)
		self.result.setStyleSheet(self.styleStr)
		self.rock = QPushButton(self.rockText, self)
		self.rock.setGeometry(30, 270, 80, 35)
		self.paper = QPushButton(self.paperText, self)
		self.paper.setGeometry(120, 270, 80, 35)
		self.scissor = QPushButton(self.scissorsText, self)
		self.scissor.setGeometry(210, 270, 80, 35)
		self.rock.clicked.connect(self.rock_action)
		self.paper.clicked.connect(self.paper_action)
		self.scissor.clicked.connect(self.scissor_action)
		self.game_reset = QPushButton(self.resetText, self)
		self.game_reset.setGeometry(100, 320, 120, 50)
		color = QGraphicsColorizeEffect(self)
		color.setColor(Qt.red)
		self.game_reset.setGraphicsEffect(color)
		self.game_reset.clicked.connect(self.reset_action)
		timer = QTimer(self)
		timer.timeout.connect(self.showTime)
		timer.start(1000)
		self.started = 1

	def language_selected(self, s):
		print("lang:", s)
		if (s == "en"):
			self.headText = "Rock Paper Scissors"
			self.windowTitle = "Game"
			self.vsText = "vs"
			self.youText = "You"
			self.computerText = "Computer"
			self.rockText = "Rock"
			self.paperText = "Paper"
			self.scissorsText = "Scissors"
			self.resetText = "Reset"
			self.drawText = "Draw match..."
			self.youWinText = "You win!"
			self.botWinText = "Bot wins!"
		if (s == "ru"):
			self.headText = "Камень Ножницы Бумага"
			self.windowTitle = "Окно игры"
			self.vsText = "vs"
			self.youText = "Вы"
			self.computerText = "Компьютер"
			self.rockText = "Камень"
			self.paperText = "Бумага"
			self.scissorsText = "Ножницы"
			self.resetText = "Сбросить"
			self.drawText = "Ничья..."
			self.youWinText = "Вы победитель!"
			self.botWinText = "Вы проиграли."
		if(self.started == 1):
			self.head.setText(self.headText)
			self.vs.setText(self.vsText)
			self.user.setText(self.youText)
			self.game_reset.setText(self.resetText)
			self.computer.setText(self.computerText)
			self.rock.setText(self.rockText)
			self.paper.setText(self.paperText)
			self.scissor.setText(self.scissorsText)
			self.setWindowTitle(self.windowTitle)
			self.reset_action()
		

	def showTime(self):
		if self.counter == -1:
			pass
		else:
			self.computer.setText(str(self.counter))
			if self.counter == 0:
				self.comp_choice = random.randint(1, 3)
				if self.comp_choice == 1:
					self.computer.setStyleSheet("border-image: url(images/Rock.png);")
				elif self.comp_choice == 2:
					self.computer.setStyleSheet("border-image: url(images/Paper.png);")
				elif self.comp_choice == 3:
					self.computer.setStyleSheet("border-image: url(images/Scissors.png);")
				self.who_won()
			self.counter -= 1

	def rock_action(self):
		self.choice = 1
		self.user.setStyleSheet("border-image: url(images/Rock.png);")
		self.counter = 3
		self.rock.setDisabled(True)
		self.paper.setDisabled(True)
		self.scissor.setDisabled(True)

	def paper_action(self):
		self.choice = 2
		self.user.setStyleSheet("border-image: url(images/Paper.png);")
		self.counter = 3
		self.rock.setDisabled(True)
		self.paper.setDisabled(True)
		self.scissor.setDisabled(True)

	def scissor_action(self):
		self.choice = 3
		self.user.setStyleSheet("border-image: url(images/Scissors.png);")
		self.counter = 3
		self.rock.setDisabled(True)
		self.paper.setDisabled(True)
		self.scissor.setDisabled(True)

	def reset_action(self):
		self.result.setText("")
		self.computer.setText(self.computerText)
		self.counter = -1
		self.rock.setEnabled(True)
		self.paper.setEnabled(True)
		self.scissor.setEnabled(True)
		self.user.setStyleSheet(self.styleStr)
		self.computer.setStyleSheet(self.styleStr)

	def who_won(self):
		if self.choice == self.comp_choice:
			self.result.setText(self.drawText)
		else:
			if self.choice == 1:
				if self.comp_choice == 2:
					self.result.setText(self.botWinText)
				else:
					self.result.setText(self.youWinText)
			elif self.choice == 2:
				if self.comp_choice == 3:
					self.result.setText(self.botWinText)
				else:
					self.result.setText(self.youWinText)
			elif self.choice == 3:
				if self.comp_choice == 1:
					self.result.setText(self.botWinText)
				else:
					self.result.setText(self.youWinText)

	def closeEvent(self, event):
		self.reset_action()
		self.closed.emit()
		QMainWindow.closeEvent(self, event)
