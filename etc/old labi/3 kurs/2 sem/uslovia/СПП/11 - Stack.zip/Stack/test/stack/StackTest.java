package stack;

public class StackTest {

}