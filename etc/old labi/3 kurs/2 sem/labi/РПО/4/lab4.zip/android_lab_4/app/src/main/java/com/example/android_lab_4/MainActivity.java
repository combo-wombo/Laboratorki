package com.example.android_lab_4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GestureDetectorCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
        implements GestureDetector.OnGestureListener, GestureDetector.OnDoubleTapListener {

    public TextView textMain;
    public ImageView imageMain;
    public ConstraintLayout layoutMain;
    public GestureDetectorCompat gestureDetector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layoutMain = findViewById(R.id.layout_main);
        textMain = findViewById(R.id.text_main);
        imageMain = findViewById(R.id.image_main);

        gestureDetector = new GestureDetectorCompat(this, this);
        gestureDetector.setOnDoubleTapListener(this);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        gestureDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onSingleTapConfirmed(@NonNull MotionEvent e) {
        Intent i = new Intent(MainActivity.this, TapActivity.class);
        i.putExtra("posX", e.getX());
        i.putExtra("posY", e.getY());
        startActivity(i);
        return false;
    }

    @Override
    public void onStart() {
        textMain.setText("Waiting for inputs...");
        imageMain.setScaleX(0);
        imageMain.setScaleY(0);
        super.onStart();
    }

    @Override
    public boolean onDoubleTap(@NonNull MotionEvent e) {
        textMain.setText("onDoubleTap (intermediate)");
        return false;
    }

    @Override
    public boolean onDoubleTapEvent(@NonNull MotionEvent e) {
        Intent i = new Intent(MainActivity.this, DoubleTapActivity.class);
        i.putExtra("posX", e.getX());
        i.putExtra("posY", e.getY());
        startActivity(i);
        return false;
    }

    @Override
    public boolean onDown(@NonNull MotionEvent e) {
        textMain.setText("onDown");
        return false;
    }

    @Override
    public void onShowPress(@NonNull MotionEvent e) {
        textMain.setText("holding...");
    }

    @Override
    public boolean onSingleTapUp(@NonNull MotionEvent e) {
        textMain.setText("onSingleTapUp");
        return false;
    }

    @Override
    public boolean onScroll(@NonNull MotionEvent e1, @NonNull MotionEvent e2, float distanceX, float distanceY) {
        String distance = (int)distanceX + " : " + (int)distanceY;
        double tan = Math.atan2(distanceY, distanceX);
        imageMain.setImageResource(R.drawable.arrow);
        imageMain.setScaleX(0.5f);
        imageMain.setScaleY(0.5f);
        imageMain.setRotation((float)(Math.toDegrees(tan) + 180));
        textMain.setText("Scrolling... (" + distance + ")");
        return false;
    }

    @Override
    public void onLongPress(@NonNull MotionEvent e) {
        Intent i = new Intent(MainActivity.this, HoldActivity.class);
        i.putExtra("posX", e.getX());
        i.putExtra("posY", e.getY());
        startActivity(i);
    }

    @Override
    public boolean onFling(@NonNull MotionEvent e1, @NonNull MotionEvent e2, float velocityX, float velocityY) {
        double tan = Math.atan2(velocityY, velocityX);
        imageMain.setImageResource(R.drawable.arrow_pointy);
        float velocity = (float)Math.sqrt(velocityX*velocityX + velocityY*velocityY);
        imageMain.setScaleX(0.6f * (velocity/19000.f));
        imageMain.setScaleY(0.6f * (velocity/19000.f));
        imageMain.setRotation((float)(Math.toDegrees(tan)));
        textMain.setText("Flinged (speed : " + velocity + ")");
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.item_info) {
            Intent i = new Intent(this, InfoActivity.class);
            startActivity(i);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}