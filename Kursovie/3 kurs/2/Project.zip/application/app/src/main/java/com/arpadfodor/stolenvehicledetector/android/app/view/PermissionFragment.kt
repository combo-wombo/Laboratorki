package com.arpadfodor.stolenvehicledetector.android.app.view

import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.arpadfodor.stolenvehicledetector.android.app.ApplicationRoot
import com.arpadfodor.stolenvehicledetector.android.app.view.utils.AppFragment
import java.lang.System.exit
import kotlin.system.exitProcess

private const val PERMISSIONS_REQUEST_CODE = 10
private val PERMISSIONS_REQUIRED = ApplicationRoot.requiredPermissions

class PermissionsFragment(finished: () -> Unit = {}) : AppFragment() {

    companion object {
        fun hasPermissions(context: Context) = PERMISSIONS_REQUIRED.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }
    val actionFinished = finished
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!hasPermissions(requireContext())) {
            // Request permissions
            requestPermissions(PERMISSIONS_REQUIRED, PERMISSIONS_REQUEST_CODE)
        }
        else {
            removeThisFragment()
        }
    }

    override fun appearingAnimations(){}
    override fun subscribeToViewModel(){}
    override fun subscribeListeners(){}
    override fun unsubscribe(){}

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSIONS_REQUEST_CODE) {
            if(grantResults.isEmpty()){
                exitProcess(0)
            }
            if (grantResults.contains(PackageManager.PERMISSION_DENIED)) {
                exitProcess(0)
            }
            else {
                //granted
            }
            removeThisFragment()
        }
    }

    private fun removeThisFragment(){
        requireActivity().supportFragmentManager.beginTransaction().remove(this).commit()
        actionFinished()
    }

}
