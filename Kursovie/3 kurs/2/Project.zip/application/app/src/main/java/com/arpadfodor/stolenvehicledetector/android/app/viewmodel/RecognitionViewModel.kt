package com.arpadfodor.stolenvehicledetector.android.app.viewmodel

import android.content.res.Resources
import android.graphics.BitmapFactory
import androidx.lifecycle.MutableLiveData
import com.arpadfodor.stolenvehicledetector.android.app.R
import com.arpadfodor.stolenvehicledetector.android.app.model.AccountService
import com.arpadfodor.stolenvehicledetector.android.app.model.api.ApiService
import com.arpadfodor.stolenvehicledetector.android.app.model.api.dataclasses.ApiReport
import com.arpadfodor.stolenvehicledetector.android.app.model.repository.UserRecognitionRepository
import com.arpadfodor.stolenvehicledetector.android.app.model.repository.dataclasses.User
import com.arpadfodor.stolenvehicledetector.android.app.model.repository.dataclasses.UserRecognition
import com.arpadfodor.stolenvehicledetector.android.app.viewmodel.utils.MasterDetailViewModel
import kotlinx.coroutines.currentCoroutineContext

class RecognitionViewModel : MasterDetailViewModel(){

    override val recognitions: MutableLiveData<List<UserRecognition>> by lazy {
        MutableLiveData<List<UserRecognition>>(listOf())
    }
    fun updateDataFromDb(){
        val rec1 = UserRecognition(0, false, false, false, "D L21ST", 1, "17.05.2023 (04:02)", "52.05753789516966", "23.738727490527417", "Andrey", "kurs bmw")
        val rec2 = UserRecognition(1, false, false, false, "B58 BPS", 2, "17.05.2023 (03:15)", "52.05753789516966", "23.738727490527417", "Test", "hi")
        val rec3 = UserRecognition(2, false, false, false, "12-XVF-8", 3, "16.05.2023 (16:31)", "52.05753789516966", "23.738727490527417", "reporter", "custom message")
        val rec4 = UserRecognition(3, false, false, false, "203TAKIR", 4, "16.05.2023 (14:50)", "52.05753789516966", "23.738727490527417", "reporter", "custom message")
        val rec5 = UserRecognition(4, false, false, false, "NOH N 755", 5, "16.05.2023 (14:47)", "52.05753789516966", "23.738727490527417", "reporter", "custom message")

        val userRecognitionList2 = mutableListOf(rec1,rec2,rec3,rec4,rec5)
        recognitions.postValue(userRecognitionList2)
    }

    override fun sendRecognition(id: Int, callback: (Boolean) -> Unit){

        val recognition = recognitions.value?.find { it.artificialId == id } ?: return
        val apiReport = ApiReport(recognition.licenseId, recognition.reporter,
            recognition.latitude.toDouble(), recognition.longitude.toDouble(),
            recognition.message, recognition.licenseId, 0, recognition.date)
        ApiService.postReport(apiReport) { isPostSuccess ->
            if(isPostSuccess){
                deselectRecognition()
                val user = AccountService.userId
                UserRecognitionRepository.updateSentFlagByIdAndUser(id, user, true){ isDbSuccess ->
                    if(isDbSuccess){
                        updateDataFromDb()
                        callback(true)
                    }
                    else{
                        callback(false)
                    }
                }
            }
            else{
                callback(false)
            }
        }
    }

    override fun updateRecognitionMessage(id: Int, message: String, callback: (Boolean) -> Unit){
        val user = AccountService.userId
        UserRecognitionRepository.updateMessageByIdAndUser(id, user, message){ isSuccess ->
            if(isSuccess){
                updateDataFromDb()
            }
            callback(isSuccess)
        }
    }

    override fun deleteRecognition(id: Int, callback: (Boolean) -> Unit){
        Thread{
            val user = AccountService.userId
            UserRecognitionRepository.deleteByIdAndUser(id, user){ isSuccess ->
                if(isSuccess){
                    deselectRecognition()
                    updateDataFromDb()
                }
                callback(isSuccess)
            }
        }.start()
    }
}