package queue;

public class QueueTest {

}